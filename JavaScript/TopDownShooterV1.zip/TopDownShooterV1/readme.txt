Controls:
WASD - Movement
Left Mouse Button - Shoot